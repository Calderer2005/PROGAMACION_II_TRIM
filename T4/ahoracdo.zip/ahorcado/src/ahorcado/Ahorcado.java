/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ahorcado;

import java.util.Scanner;

/**
 *
 * @author EAG
 */
public class Ahorcado {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        String palabra = generarPalabra();
        String adivina = "";
        
        char[] letrasUsadas = new char[26];
        int topeUsd = 0;
        
        char[] letrasValidas = new char[26];
        int topeVal = 0;
        
        String cont = "";
        
        int fallos = 0;
        
        boolean gana = false;
        boolean pierde = false;
        
        for(int i = 0; i < palabra.length(); i++)
            System.out.print("_ ");
        
        do{
            boolean esta = compLetra(sc, letrasUsadas, topeUsd, palabra);
            topeUsd++;
            
            if(esta){
                letrasValidas[topeVal] = letrasUsadas[topeUsd-1];
                topeVal++;
            }else{
               fallos++; 
               cont=dibujarMoñe(cont, fallos);
            }
  
            adivina = validarLetra(palabra, letrasValidas, topeVal);
            
            System.out.println("\nFallos: " + fallos + '\n');
            
            if(cont!="") System.out.println(cont + "\n");
            
            System.out.print("Letras utilizadas: ");
            
            for (int i = 0; i < topeUsd-1; i++){
                System.out.print(letrasUsadas[i] + ",");
            }
            System.out.println(letrasUsadas[topeUsd-1]);
            
            gana = palabra.equals(adivina);
            pierde = fallos >= 5;
            
        }while(!gana && !pierde);
        
        if(gana) System.out.println("\n¡HAS GANADO!");
        
        if(pierde) System.out.println("\nHas perdido. La palabra era "+palabra);
    }
    
    public static String generarPalabra(){
        String[] lista = {"esternocleidomastoideo", "hipocampo", "equilicua", "repampanos", "retruecano", "albricias", "fierabras", "malandrin", "recorcholis", "tenguerengue"};
        int index =(int) (Math.random()*(lista.length));
        
        return lista[index];
    }
    
    public static String dibujarMoñe(String cont, int fallos){
        String cont1 = "_\n |";
        String cont2 = "\n o";
        String cont3 = "\n-|-";
        String cont4 = "\n/ ";
        String cont5 = "\\";
        
        switch(fallos){
            case 1:
                cont += cont1;
                break;
             case 2:
                cont += cont2;
                break;
             case 3:
                cont += cont3;
                break;
             case 4:
                cont += cont4;
                break;
             case 5:
                cont += cont5;
                break;
        }
        return cont;
    }
    
    public static boolean compLetra(Scanner sc, char[] letrasUsadas, int tope, String palabra){
        char c;
        boolean usada = false;
        boolean esta = false;
        
        do{
            usada = false;
            System.out.println("\nIntroduce una letra:");
            c = sc.next().charAt(0);

            for(int i = 0; i < tope && !usada; i++){
                if (c == letrasUsadas[i])
                    usada = true;
            }
        }while(usada);

        for(int i = 0; i < palabra.length() && !esta; i++){
            if(c == palabra.charAt(i))
                esta = true;
        }

        letrasUsadas[tope] += c;
        return esta;
    }
    
    public static String validarLetra(String palabra, char[] letrasValidas, int topeVal){
        boolean esta = false;
        String adivina = "";
        
        for(int i = 0; i < palabra.length(); i++){
            esta = false;
            char k = palabra.charAt(i);

            for(int j = 0; j < topeVal && !esta; j++){
                if (k == letrasValidas[j])
                    esta = true;
            }

            if (esta){
                adivina += k;
                System.out.print(k+" ");
            }
            else{
                adivina += '_';
                System.out.print("_ ");
            }
        }
        return adivina;
    }
    
}
