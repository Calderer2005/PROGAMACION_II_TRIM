/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejs;

import java.util.Scanner;

/**
 *
 * @author EAG
 */
public class Ejs {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        int num = 0;
        do{
            try{
                num = sc.nextInt();
            }catch(Exception e){
                System.out.println("No se ha introducido un númeor entero");
            }
        }while(num < 1 || num >= 4000);
        
        numRomano(num);
    }
    
    public static void numRomano(int num){
        final int[] LISTANUM = {1000, 500, 100, 50, 10, 5, 1};
        final char[] LETRAS = {'M', 'D', 'C', 'L', 'X', 'V', 'I'};
        int tope = LETRAS.length;
        
        int res = 0;
        int res2 = 0;
        
        String palabra = "";
        
        for(int i = 0; i < tope; i++){
            res = num/LISTANUM[i];
            
            if(res != 0){
                if(i%2 != 0 && res == 1){

                    num%=LISTANUM[i];
                    res2 = num/LISTANUM[i+1];
                    if(res2 == 4){
                        palabra += LETRAS[i+1] + "" + LETRAS[i-1];
                        i++;
                    }else{
                        for(int j = 0; j < res; j++)
                            palabra+=LETRAS[i];
                    }
                    
                }else if(res == 4){
                    palabra += LETRAS[i] + "" + LETRAS[i-1];    
                }else{
                    for(int j = 0; j < res; j++)
                        palabra+=LETRAS[i];
                }
            }    
            num %= LISTANUM[i];
        }
        
        System.out.println("El número insertado en números romanos es: "+palabra);
    }
    
}
