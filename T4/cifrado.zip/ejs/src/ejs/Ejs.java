/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejs;

/**
 *
 * @author EAG
 */
public class Ejs {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String f = cifrado("Me llamo Erica y me gusta programar.", 10);
        System.out.println(f);
        System.out.println(descifrado(f));
    }
    
    public static String cifrado(String s, int k){
        String cif = "";
        int val = 'z'-'a'+1;
        char ini = 'a';
        
        for(char c : s.toCharArray()){
            if(c >= 'A' && c <= 'Z')
                ini = 'A';
            else if(c >= 'a' && c <= 'z')
                ini = 'a';
            else
                ini = 'ñ';
            
            if(ini == 'A' || ini == 'a')
                cif += (char) (ini+((c-ini+k)%val));
            else
                cif += c;
        }
        return cif;
    } 
    
    public static String descifrado(String s){
        String[] lista = {"de", "el", "la", "en", "que", "los", "se", "un", "las", "con", "no"};
        String[] palabras = s.toLowerCase().split(" ");
        int tope = 'z'-'a';
        int k = -1;
        boolean enc = false;
        
        for(String p: lista){
            for(String comp: palabras){
                if(p.length()==comp.length()){
                    for(int i = 0; i <= tope; i++){
                        if(p.equals(cifrado(comp,i))){
                            k = i;
                            enc = true;
                            break;
                        }
                    }
                }
                if(enc) break;
            }
            if(enc) break;
        }
        String resp = "No se ha encontrado";
        if(k != -1) resp = cifrado(s, k);
        
        return resp;
    }
    
}
